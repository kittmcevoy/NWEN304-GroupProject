module.exports = {
	'googleAuth' : {
	'clientId': '219456515320-921oap9mmpmc88lqac5q1e2vehibkcjl.apps.googleusercontent.com',
	'clientSecret': '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',
	'callbackUrl': 'https://nwen304-group-host.herokuapp.com/google/callback'
	}
};
