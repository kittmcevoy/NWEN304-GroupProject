module.exports = {
    url: 'mongodb+srv://Si-senor:Si-senor@nwengroupok.3dchqjt.mongodb.net/appdb?appName=mongosh+1.6.0',
  };