Site is hosted on heroku: https://nwen304-group-host.herokuapp.com/

to run locally:
1. Navigate into local folder
2. npm install
3. npm start
4. open browser and go to "localhost:3000"